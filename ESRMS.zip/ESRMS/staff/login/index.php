<?php
session_start();
include('../../db.php');
require '../../logs/log_action.php';

// Initialize error message
$error = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Prepare SQL query to fetch admin details
    $sql = "SELECT * FROM admin WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            // Check if the user role is not admin
            if ($user['role'] !== 'admin') {
                // Successful login, log it
                log_action($conn, $user['id'], $user['username'], $user['role'], "User logged in");

                // Regenerate session ID
                session_regenerate_id(true);
                $_SESSION['admin'] = $user['username'];
                $_SESSION['role'] = $user['role']; // Store the role from admin table
                $_SESSION['welcome_message'] = "Welcome to the Staff Panel!";

                header("Location: ./../dashboard.php");
                exit();
            } else {
                // Staff role is not allowed to log in here
                log_action($conn, $user['id'], $user['username'], $user['role'], "Staff attempted admin login");
                $error = "Access denied!";
            }
        } else {
            // Incorrect password
            log_action($conn, 0, $username, 'N/A', "Failed login attempt");
            $error = "Invalid password!";
        }
    } else {
        // Username not found
        log_action($conn, 0, $username, 'N/A', "Failed login attempt");
        $error = "Invalid username!";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login into SIDRS</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <style>
        body {
            background-image: linear-gradient(120deg, #84fab0 0%, #8fd3f4 100%);
            height: 100vh;
            margin: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            font-family: "Helvetica Neue", Arial, sans-serif;
        }

        .wrapper {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            width: 100%;
        }

        .container-box {
            background-color: white;
            border-radius: 12px;
            border: 1px solid #dee2e6;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.20);
            width: 400px;
            padding: 25px;
            text-align: center;
            margin-top: auto;
            margin-bottom: auto;
        }

        .logo-box {
            width: 100px;
            margin: 0 auto 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 0px;
        }

        h5 {
            font-size: 1.6rem;
            font-weight: bold;
            color: #4267B2;
            margin-bottom: 5px;
            margin-top: 10px;
        }

        p {
            font-size: 1rem;
            color: #6c757d;
            margin-bottom: 20px;
        }

        .form-control {
            padding: 12px 18px;
            border-radius: 8px;
            font-size: 14px;
        }

        .btn-custom {
            width: 100%;    
            padding: 12px;
            font-size: 15px;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .btn-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
        }

        .btn-blue {
            background-color: #4267B2;
            color: white;
            border: none;
        }

        .btn-blue:hover {
            background-color: #007bb8;
        }

        footer {
            margin-top: 20px;
            font-size: 14px;
            color: #495057;
            letter-spacing: 0.5px;
        }

        .input-icon {
    position: relative;
}


.input-group-text {
    background-color: #f8f9fa;
    border: 1px solid #ced4da;
    border-right: none;
    border-radius: 8px 0 0 8px;
    padding: 12px 12px;
    color:rgb(30, 111, 192);
}


.input-group-prepend,
.input-group-append {
    display: flex;
    align-items: center;  /* Ensure icons are aligned correctly */
}

.input-group .form-control:focus {
    box-shadow: none;  /* Remove box-shadow when focused for clean appearance */
    border-color: #80bdff;  /* Change border color on focus */
}

        .form-group {
            margin-bottom: 18px;
        }

        .alert-danger {
            padding: 10px;
            background-color: #f8d7da;
            color: #721c24;
            border-radius: 8px;
            margin-bottom: 15px;
        }
    </style>
</head>

<body>

<div class="wrapper">
    <div class="container-box">
        <!-- Logo Section -->
        <div class="logo-box">
            <img src="../../pictures/12.jpg" alt="Logo" style="width: 100%; height: auto; object-fit: contain;">
        </div>

        <!-- Login Heading -->
            <h5>Staff Login</h5><p>

            <!-- Show Error Message -->
            <?php if (!empty($error)) : ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

 <!-- Login Form -->
<form method="POST" action="" id="loginForm">
<div class="form-group mb-3">
  <div class="input-group position-relative">
    <span class="input-group-text bg-transparent border-0 position-absolute start-0 ps-3">
      <i class="fas fa-user text-muted"></i>
    </span>
    <input type="text" name="username" class="form-control ps-5" placeholder="Enter Username" required>
  </div>
</div>

<div class="form-group mb-3">
  <div class="input-group position-relative">
    <span class="input-group-text bg-transparent border-0 position-absolute start-0 ps-3">
      <i class="fas fa-lock text-muted"></i>
    </span>
    <input type="password" name="password" class="form-control ps-5" id="password" placeholder="Enter Password" required>

  </div>
</div>

<style>
  .form-control {
    border-radius: 10px;
    padding: 12px 15px;
    font-size: 14px;
    border: 1px solid #ced4da;
    background: #fff;
    transition: all 0.3s ease;
  }

  .form-control:focus {
    border-color: #80bdff;
    box-shadow: 0 0 8px rgba(0,123,255,0.25);
  }

  .input-group-text {
    border: none;
    background: transparent;
  }
</style>


    <button type="submit" class="btn btn-blue btn-custom">Log In</button>

    <footer class="text-center text-muted mt-2">
        <small>&copy; 2025 Student ID Registration System | Bobby Domdom Jr</small>
    </footer>
</form>
    </div>

    <!-- Footer Section -->
</div>

<!-- Bootstrap JS & jQuery -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>

<script>
    $(document).ready(function () {
        // Toggle password visibility
        $("#togglePassword").click(function () {
            const passwordField = $("#password");
            const type = passwordField.attr("type") === "password" ? "text" : "password";
            passwordField.attr("type", type);
            $(this).toggleClass("fa-eye fa-eye-slash");
        });
    });
</script>

</body>

</html>
