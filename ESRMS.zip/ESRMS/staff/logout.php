<?php
session_start();
require '../db.php';           // your DB connection file
require '../logs/log_action.php';  // the log_action function

// Get user details from session before clearing it
$user_id = $_SESSION['user_id'] ?? null;
$username = $_SESSION['username'] ?? null;
$role = $_SESSION['role'] ?? null;

// Log the logout action only if user is logged in
if ($user_id !== null && $username !== null) {
    log_action($conn, $user_id, $username, $role, "User logged out");
}

// Clear all session variables
$_SESSION = [];

// Destroy session cookie if exists
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

// Destroy the session
session_destroy();

// Redirect to login page with logout success message
header("Location: ./login/index.php?logout=success");
exit();
?>
