<?php
session_start();
require_once('../db.php');

if (!isset($_SESSION['admin']) || $_SESSION['role'] !== 'staff') {
    header("Location: ./login/index.php");
    exit();
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mode = $_POST['mode'] ?? '';
    $fields = [
        'lastname','firstname','dob','gender','email','phone','studentno',
        'course','yearlevel','block','address','contactname','contactno','relationship'
    ];

    foreach ($fields as $f) {
        if (empty($_POST[$f])) {
            $errors[] = ucfirst($f) . " is required.";
        }
    }

    if ($mode === 'old' && empty($_POST['or_number'])) {
        $errors[] = "OR number is required for reprint.";
    }

    $pictureFile = null;
    if (!empty($_POST['cropped_image'])) {
        $imageData = $_POST['cropped_image'];
        $imageParts = explode(";base64,", $imageData);
        if (count($imageParts) === 2) {
            $imageBase64 = base64_decode($imageParts[1]);
            $pictureFile = 'uploads/picture_' . time() . '.jpg';
            file_put_contents("../$pictureFile", $imageBase64);
        }
    }

    if (empty($errors)) {
$stmt = $conn->prepare("
    INSERT INTO student_registration 
    (studentno, lastname, firstname, dob, gender, email, phone, course, yearlevel, block, address, contactname, contactno, relationship, picture, registration_date, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), 'pending')
");

        $stmt->bind_param(
    "ssssssssssssssss",
    $_POST['studentno'],
    $_POST['lastname'],
    $_POST['firstname'],
    $_POST['dob'],
    $_POST['gender'],
    $_POST['email'],
    $_POST['phone'],
    $_POST['course'],
    $_POST['yearlevel'],
    $_POST['block'],
    $_POST['address'],
    $_POST['contactname'],
    $_POST['contactno'],
    $_POST['relationship'],
    $pictureFile
);


        $stmt->execute();
        $stmt->close();
        header("Location: registration.php?success=1");
        exit();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Register Student - Step-by-Step</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <script src="../dist/axios/axios.min.js"></script>  <style>
  <style>
    body {
      background: #f4f6f9;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      padding: 100px 10px;
  min-height: 100vh;
  margin: 0; /* Remove default margin */
  overflow-x: hidden; /* Prevent horizontal scroll */
    }
    .modal-content {
      overflow: visible;
    }
    .fade-in {
      animation: fadeIn 0.5s ease-in-out;
    }
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    #progressBar {
      height: 6px;
    }

#sidebar {
  width: 240px;
  background: #343a40;
  color: #fff;
  flex-shrink: 0; /* Prevent shrinking */
  height: 100vh; /* Full height */
  position: fixed; /* Fix sidebar position */
  top: 0;
  left: 0;
  overflow-y: auto; /* Scroll if content overflows */
}

#content {
  margin-left: 240px; /* Offset content to the right of sidebar */
  flex: 1;
  padding: 20px;
  background: #f4f6f9;
  min-height: 100vh;
  overflow-y: auto;
}
  </style>
</head>

<body>
  <?php include __DIR__ . '/../includes/sidebar1.php'; ?>
  <!-- Sidebar unchanged -->
  <div id="content">
<?php if (!empty($errors)): ?>
  <div class="alert alert-danger w-100"><ul><?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul></div>
<?php elseif (isset($_GET['success'])): ?>
  <div class="alert alert-success w-100">Student registered successfully!</div>
<?php endif; ?>

<!-- Modal Wizard -->
<div class="modal-dialog modal-lg">
  <div class="modal-content shadow-sm p-4">
    <h4 class="mb-3 text-primary">Student Registration</h4>

    <!-- Progress Bar -->
    <div class="progress mb-4">
      <div id="progressBar" class="progress-bar bg-primary" role="progressbar" style="width: 0%"></div>
    </div>

    <form id="registrationForm" method="POST" class="needs-validation" novalidate>
      <!-- Step 1: Student Type -->
      <div class="form-step" data-step="1">
        <label class="form-label fw-bold mb-3">Student Type</label>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="mode" id="modeNew" value="new" required>
          <label class="form-check-label" for="modeNew">🆕 New Student</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="mode" id="modeOld" value="old" required>
          <label class="form-check-label" for="modeOld">♻️ Reprint (Old Student)</label>
        </div>
        <div class="invalid-feedback">Please select a student type.</div>

        <!-- OR Number (conditionally shown) -->
        <div id="orField" class="mt-3" style="display:none;">
          <label for="or_number" class="form-label">OR Number <span class="text-danger">*</span></label>
          <input type="text" name="or_number" id="or_number" class="form-control">
          <div class="invalid-feedback">OR number is required for reprint.</div>
        </div>

        <div class="mt-4 text-end">
          <button type="button" class="btn btn-primary" id="nextBtn1">Next →</button>
        </div>
      </div>

      <!-- Step 2: Student Info -->
      <div class="form-step d-none" data-step="2">
        <h5 class="text-primary mb-3">🎓 Student Information</h5>
        <div class="row g-3">
          <?php
          $fields = [
            'Student No.' => 'studentno','Last Name'=>'lastname','First Name'=>'firstname',
            'Birthdate'=>'dob','Gender (M/F)'=>'gender','Email'=>'email','Phone'=>'phone',
            'Course/Strand'=>'course','Year/Grade Level'=>'yearlevel','Block'=>'block',
            'Address'=>'address'
          ];
          foreach ($fields as $label => $name) {
            echo "<div class='col-md-6'>
                    <label for='$name' class='form-label'>$label <span class='text-danger'>*</span></label>
                    <input type='text' name='$name' id='$name' class='form-control' required>
                    <div class='invalid-feedback'>$label is required.</div>
                  </div>";
          }
          ?>
        </div>
        <div class="mt-4 d-flex justify-content-between">
          <button type="button" class="btn btn-secondary" id="prevBtn2">← Previous</button>
          <button type="button" class="btn btn-primary" id="nextBtn2">Next →</button>
        </div>
      </div>

      <!-- Step 3: Emergency Contact -->
      <div class="form-step d-none" data-step="3">
        <h5 class="text-primary mb-3">📞 Emergency Contact</h5>
        <div class="row g-3">
          <?php
          $ec = ['Emergency Contact Name'=>'contactname','Emergency Contact No.'=>'contactno','Relationship'=>'relationship'];
          foreach ($ec as $label => $name) {
            echo "<div class='col-md-6'>
                    <label for='$name' class='form-label'>$label <span class='text-danger'>*</span></label>
                    <input type='text' name='$name' id='$name' class='form-control' required>
                    <div class='invalid-feedback'>$label is required.</div>
                  </div>";
          }
          ?>
        </div>
        <div class="mt-4 d-flex justify-content-between">
          <button type="button" class="btn btn-secondary" id="prevBtn3">← Previous</button>
          <button type="button" class="btn btn-primary" id="nextBtn3">Next →</button>
        </div>
      </div>

      <!-- Step 4: Photo Upload -->
      <div class="form-step d-none" data-step="4">
        <h5 class="text-primary mb-3">📷 Student Photo</h5>
        <div class="mb-2">
          <input type="file" id="uploadImage" accept="image/*" class="form-control mb-2" aria-label="Upload student photo">
          <button type="button" class="btn btn-outline-primary btn-sm me-2" onclick="openCamera()">📸 Use Webcam</button>
        </div>
        <div id="imagePreview" class="text-center mt-3">
          <img id="croppedImage" src="" class="img-thumbnail" style="max-height:200px; display:none;" alt="Cropped photo preview">
          <input type="hidden" name="cropped_image" id="croppedData" />
        </div>
        <div class="mt-4 d-flex justify-content-between">
          <button type="button" class="btn btn-secondary" id="prevBtn4">← Previous</button>
          <button type="submit" class="btn btn-success px-4">✅ Submit Registration</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Webcam Modal -->
<div class="modal fade" id="webcamModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Capture from Webcam</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center">
        <video id="webcamVideo" autoplay playsinline class="border mb-2" style="width: 100%; max-height: 400px;"></video><br>
        <button type="button" class="btn btn-success" onclick="capturePhoto()">📸 Capture</button>
      </div>
    </div>
  </div>
</div>

<!-- Crop Modal -->
<div class="modal fade" id="cropModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Crop Photo</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center">
        <canvas id="cropCanvas" style="max-width: 100%; border:1px solid #ddd;"></canvas>
        <div class="mt-3">
          <button type="button" class="btn btn-primary" id="cropConfirmBtn">Confirm Crop</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
(() => {
  'use strict';

  // Form Step Handling
  let currentStep = 1;
  const totalSteps = 4;
  const form = document.getElementById('registrationForm');
  const progressBar = document.getElementById('progressBar');
  const steps = form.querySelectorAll('.form-step');

  function showStep(step) {
    steps.forEach(el => {
      el.classList.toggle('d-none', parseInt(el.dataset.step) !== step);
      if(parseInt(el.dataset.step) === step) {
        el.classList.add('fade-in');
      } else {
        el.classList.remove('fade-in');
      }
    });
    // Update progress bar
    progressBar.style.width = ((step - 1) / (totalSteps - 1)) * 100 + '%';
  }

  function validateStep(step) {
    const stepEl = form.querySelector(`.form-step[data-step="${step}"]`);
    const inputs = stepEl.querySelectorAll('input[required]');
    let valid = true;
    inputs.forEach(input => {
      if (input.type === "radio") {
        const radios = stepEl.querySelectorAll(`input[name="${input.name}"]`);
        if (![...radios].some(r => r.checked)) {
          input.closest('.form-check')?.classList.add('is-invalid');
          valid = false;
        } else {
          radios.forEach(r => r.closest('.form-check')?.classList.remove('is-invalid'));
        }
      } else if (!input.value.trim()) {
        input.classList.add('is-invalid');
        valid = false;
      } else {
        input.classList.remove('is-invalid');
      }
    });
    return valid;
  }

  function updateOrFieldVisibility() {
    const modeOld = form.querySelector('input[name="mode"][value="old"]');
    const orField = document.getElementById('orField');
    if (modeOld.checked) {
      orField.style.display = 'block';
      orField.querySelector('input').setAttribute('required', 'required');
    } else {
      orField.style.display = 'none';
      orField.querySelector('input').removeAttribute('required');
      orField.querySelector('input').value = '';
      orField.querySelector('input').classList.remove('is-invalid');
    }
  }

  // Next/Previous buttons
  document.getElementById('nextBtn1').addEventListener('click', () => {
    if (validateStep(1)) {
      updateOrFieldVisibility();
      if (!validateStep(1)) return; // revalidate after OR field shown
      currentStep++;
      showStep(currentStep);
    }
  });

  document.getElementById('nextBtn2').addEventListener('click', () => {
    if (validateStep(2)) {
      currentStep++;
      showStep(currentStep);
    }
  });

  document.getElementById('nextBtn3').addEventListener('click', () => {
    if (validateStep(3)) {
      currentStep++;
      showStep(currentStep);
    }
  });

  document.getElementById('prevBtn2').addEventListener('click', () => {
    currentStep--;
    showStep(currentStep);
  });

  document.getElementById('prevBtn3').addEventListener('click', () => {
    currentStep--;
    showStep(currentStep);
  });

  document.getElementById('prevBtn4').addEventListener('click', () => {
    currentStep--;
    showStep(currentStep);
  });

  // Show OR number input if mode = old
  form.querySelectorAll('input[name="mode"]').forEach(radio => {
    radio.addEventListener('change', updateOrFieldVisibility);
  });

  // Bootstrap native validation on submit
  form.addEventListener('submit', e => {
    if (!form.checkValidity()) {
      e.preventDefault();
      e.stopPropagation();
    }
    form.classList.add('was-validated');
  });

  // Initialize first step
  showStep(currentStep);

  // Webcam and crop functionality (basic)
  let webcamStream;
  const webcamModal = new bootstrap.Modal(document.getElementById('webcamModal'));
  const cropModal = new bootstrap.Modal(document.getElementById('cropModal'));
  const video = document.getElementById('webcamVideo');
  const canvas = document.getElementById('cropCanvas');
  const ctx = canvas.getContext('2d');
  const croppedImage = document.getElementById('croppedImage');
  const croppedData = document.getElementById('croppedData');
  let imgToCrop = new Image();

  window.openCamera = function() {
    navigator.mediaDevices.getUserMedia({ video: true })
      .then(stream => {
        webcamStream = stream;
        video.srcObject = stream;
        webcamModal.show();
      })
      .catch(() => alert("Cannot access webcam."));
  };

  window.capturePhoto = function() {
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0);
    webcamStream.getTracks().forEach(track => track.stop());
    webcamModal.hide();

    // Load captured image into crop modal
    imgToCrop.src = canvas.toDataURL('image/png');
    imgToCrop.onload = () => {
      // Set canvas size to cropped image
      canvas.width = imgToCrop.width;
      canvas.height = imgToCrop.height;
      ctx.drawImage(imgToCrop, 0, 0);
      cropModal.show();
    };
  };

  // Confirm crop button
  document.getElementById('cropConfirmBtn').addEventListener('click', () => {
    // For simplicity, use entire canvas as cropped image
    const croppedDataUrl = canvas.toDataURL('image/jpeg', 0.9);
    croppedImage.src = croppedDataUrl;
    croppedImage.style.display = 'inline-block';
    croppedData.value = croppedDataUrl;
    cropModal.hide();
  });

  // File upload preview and crop modal
  document.getElementById('uploadImage').addEventListener('change', function() {
    const file = this.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(e) {
      imgToCrop.src = e.target.result;
      imgToCrop.onload = () => {
        canvas.width = imgToCrop.width;
        canvas.height = imgToCrop.height;
        ctx.drawImage(imgToCrop, 0, 0);
        cropModal.show();
      };
    };
    reader.readAsDataURL(file);
  });

})();
</script>

</body>
</html>
