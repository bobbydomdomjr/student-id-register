<?php
// staff/search_ajax.php
session_start();
require_once('../db.php');
header('Content-Type: application/json');

if (!isset($_SESSION['admin']) || $_SESSION['role'] !== 'staff') {
    echo json_encode([]);
    exit();
}

$query = trim($_GET['q'] ?? '');
if ($query === '') {
    echo json_encode([]);
    exit();
}

$like = "%$query%";
$stmt = $conn->prepare("
    SELECT studentno, firstname, lastname, course, yearlevel, status
    FROM student_registration
    WHERE studentno LIKE ? OR firstname LIKE ? OR lastname LIKE ?
    ORDER BY registration_date DESC
    LIMIT 100
");
$stmt->bind_param("sss", $like, $like, $like);
$stmt->execute();
$results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

echo json_encode($results);
