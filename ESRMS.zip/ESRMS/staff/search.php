<?php
// staff/search.php
session_start();
require_once('../db.php');

if (!isset($_SESSION['admin']) || $_SESSION['role'] !== 'staff') {
    header("Location: ./login/index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student Search</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

  <script src="../dist/axios/axios.min.js"></script>
  <style>
    body {
      display: flex;
      min-height: 100vh;
      margin: 0;
      overflow-x: hidden;
    }

    #sidebar {
      width: 240px;
      background: #343a40;
      color: #fff;
      flex-shrink: 0;
      height: 100vh;
      position: fixed;
      top: 0;
      left: 0;
      overflow-y: auto;
    }

    #content {
      margin-left: 240px;
      flex: 1;
      padding: 2rem;
      background: #f4f6f9;
    }

    .search-box {
      position: relative;
    }

    .search-box input {
      padding-left: 2.5rem;
      border-radius: 50px;
    }

    .search-box .bi-search {
      position: absolute;
      top: 50%;
      left: 1rem;
      transform: translateY(-50%);
      color: #6c757d;
    }

    .status-badge {
      padding: 0.25em 0.5em;
      border-radius: 0.375rem;
      font-size: 0.875rem;
    }

    .fade-in {
      animation: fadeIn 0.4s ease-in-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>
  <?php include __DIR__ . '/../includes/sidebar1.php'; ?>

  <div id="content">
    <div class="card shadow p-4">
      <h4 class="mb-4">Search Students</h4>

      <div class="search-box mb-4">
        <i class="bi bi-search"></i>
        <input type="text" id="search-input" class="form-control shadow-sm" placeholder="Search by Name or Student No.">
      </div>

      <div id="search-results" class="fade-in">
        <div class="text-center text-muted">Start typing to search…</div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <script>
    const input = document.getElementById('search-input');
    const resultsDiv = document.getElementById('search-results');
    let timer;

    input.addEventListener('input', () => {
      clearTimeout(timer);
      const query = input.value.trim();
      if (query.length < 2) {
        resultsDiv.innerHTML = '<div class="text-center text-muted fade-in">Keep typing…</div>';
        return;
      }

      timer = setTimeout(() => {
        axios.get('search_ajax.php?q=' + encodeURIComponent(query))
          .then(({ data }) => {
            if (data.length === 0) {
              resultsDiv.innerHTML = `<div class="alert alert-warning text-center fade-in">No results for "<strong>${query}</strong>"</div>`;
              return;
            }

            let html = `
              <div class="mb-2"><strong>Results:</strong> ${data.length}</div>
              <div class="table-responsive fade-in">
              <table class="table table-bordered align-middle table-hover">
                <thead class="table-light">
                  <tr>
                    <th>Student No.</th>
                    <th>Name</th>
                    <th>Course</th>
                    <th>Year</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
            `;

            data.forEach(r => {
              const badge = getStatusBadgeClass(r.status);
              html += `
                <tr>
                  <td>${r.studentno}</td>
                  <td>${r.firstname} ${r.lastname}</td>
                  <td>${r.course}</td>
                  <td>${r.yearlevel}</td>
                  <td><span class="status-badge bg-${badge} text-white">${capitalize(r.status)}</span></td>
                </tr>`;
            });

            html += '</tbody></table></div>';
            resultsDiv.innerHTML = html;
          })
          .catch(() => {
            resultsDiv.innerHTML = `<div class="alert alert-danger text-center fade-in">Error loading results.</div>`;
          });
      }, 300); // debounce delay
    });

    function getStatusBadgeClass(status) {
      switch (status.toLowerCase()) {
        case 'processing': return 'success';
        case 'inactive': return 'secondary';
        case 'pending': return 'warning';
        case 'blocked': return 'danger';
        case 'done': return 'info';
        default: return 'dark';
      }
    }

    function capitalize(s) {
      return s.charAt(0).toUpperCase() + s.slice(1);
    }
  </script>
</body>
</html>
