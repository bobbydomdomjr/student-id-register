-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2025 at 08:43 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esrms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `role`) VALUES
(1, 'superadmin', '$2y$10$fbz4v.DfwqgzLkSGzbFFW.GFI5ahZ597cOoiBuQnYONEOZRRloSyS', 'superadmin'),
(3, 'admin', '$2y$10$bUZuk47Zvos.uKkEeWNLaeQ43mri7ZTcuj3nHXYMQCU4hCE7YVEK.', 'admin'),
(4, 'staff', '$2y$10$gl1lKOfrEXGtnc3lnK0JFeT/37Ksm6g/GFpEMP.iiBJzIBieeeX72', 'staff'),
(10, 'bobbydomdomjr', '$2y$10$yMr9VxoMGIPORgEs8lkkQuKg4oIKaxQEU.6bhitmURVTL3waeBPfq', 'staff');

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`id`, `filename`, `start_time`, `end_time`, `uploaded_at`) VALUES
(78, 'ads/1748511309_PN.jpg', '2025-05-29 01:34:00', '2025-05-29 22:35:00', '2025-05-29 09:35:09'),
(81, 'ads/1748667408_1746174695_Screenshot_23-4-2025_111447_localhost.jpeg', '2025-05-31 00:56:00', '2025-06-04 12:56:00', '2025-05-31 04:56:48'),
(82, 'ads/1748702065_Screenshot_31-5-2025_223353_localhost.jpeg', '2025-05-30 10:34:00', '2025-06-04 22:34:00', '2025-05-31 14:34:25'),
(83, 'ads/1756793084_flat-lay-desk-concept-with-copy-space.jpg', '2025-09-01 14:04:00', '2025-09-05 14:04:00', '2025-09-02 06:04:44');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('unread','read') DEFAULT 'unread'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `queuing_enabled` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `queuing_enabled`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `student_registration`
--

CREATE TABLE `student_registration` (
  `id` int(11) NOT NULL,
  `studentno` varchar(20) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `extname` varchar(10) DEFAULT NULL,
  `middleinitial` varchar(3) DEFAULT NULL,
  `dob` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `phone` varchar(15) NOT NULL,
  `course` varchar(50) NOT NULL,
  `yearlevel` varchar(20) NOT NULL,
  `block` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `contactname` varchar(50) NOT NULL,
  `contactno` varchar(15) NOT NULL,
  `relationship` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `registration_date` datetime DEFAULT current_timestamp(),
  `status` enum('pending','processing','done','no-show') NOT NULL DEFAULT 'pending',
  `now_serving` tinyint(1) NOT NULL DEFAULT 0,
  `notified` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_registration`
--

INSERT INTO `student_registration` (`id`, `studentno`, `lastname`, `firstname`, `extname`, `middleinitial`, `dob`, `email`, `picture`, `gender`, `phone`, `course`, `yearlevel`, `block`, `address`, `contactname`, `contactno`, `relationship`, `created_at`, `updated_at`, `registration_date`, `status`, `now_serving`, `notified`) VALUES
(75, '02000495467', 'Marcelo', 'Mary Grace', NULL, 'n', '1994-02-24', 'mary.marcelo@nagastiedu', '../uploads/student_02000495467_1748529970.jpeg', 'Female', '0999-999-9889', 'IT MAWD', 'Grade 11', 'A', 'rtrhdfhchfd', 'Sfssddf', '0992-986-8565', 'Guardian', '2025-04-23 03:11:18', '2025-06-01 08:51:38', '2025-05-23 11:11:18', 'done', 0, 0),
(88, '02000342423', 'Asdasd', 'Adad', NULL, '', '2025-04-10', 'domdom.342423@naga.sti.edu.ph', '', 'Male', '0951-103-3187', 'ABM', 'Grade 11', '', 'wdasghj', 'JUAN ANTONIO V DELA CRUZ', '0985-413-2410', 'Sibling', '2025-04-25 05:01:40', '2025-09-02 06:15:19', '2025-05-25 13:01:40', 'processing', 1, 0),
(89, '02000334544', 'Sda', 'Dasdsad', NULL, '', '2025-04-08', 'delacruz.334544@naga.sti.edu.ph', '', 'Female', '0951-103-3187', 'ABM', 'Grade 11', '', 'wad\'sdfg', 'JUAN ANTONIO V DELA CRUZ', '0950-859-0850', 'Sibling', '2025-04-25 06:22:35', '2025-05-31 01:21:22', '2025-05-25 14:22:35', 'done', 0, 0),
(91, '02000987456', 'Mndz', 'Km', NULL, 'A', '2000-12-01', 'mndz.987456@naga.sti.edu.ph', '', 'Male', '0912-345-6789', 'BS Information Technology', '1st Yr.', 'B', '123 ABC  QWERTY', 'EM', '0998-765-4321', 'Relative', '2025-05-28 10:28:54', '2025-05-31 14:19:05', '2025-05-28 18:28:54', 'done', 0, 0),
(93, '02000452135', 'Doe', 'John', NULL, '', '2000-02-01', 'doe.452135@naga.sti.edu.ph', '', 'Male', '0923-418-3153', 'IT MAWD', 'Grade 12', 'A', 'asdsaxaxza', 'Saxasx', '0953-435-1511', 'Relative', '2025-05-30 04:31:22', '2025-05-31 04:54:54', '2025-05-30 12:31:22', 'done', 0, 0),
(94, '02000531132', 'Dasd', 'Sads', NULL, '', '2104-02-01', 'dasd.531132@naga.sti.edu.ph', '', 'Male', '0962-315-3121', 'ABM', 'Grade 11', 'A', 'asdasd', 'Sdas', '0953-111-3131', 'Relative', '2025-05-30 04:33:48', '2025-05-31 05:06:32', '2025-05-30 12:33:48', 'done', 0, 1),
(97, '02000203462', 'Caranza', 'Janelle France', NULL, 'L', '2004-06-03', 'caranza.203462@naga.sti.edu.ph', '../uploads/student_02000203462_1748701197.png', 'Female', '0912-345-7852', 'BS Hospitality Management', '3rd Yr.', 'A', 'Naga City', 'Jhanella', '0987-432-1851', 'Parent', '2025-05-31 14:18:08', '2025-06-01 04:57:33', '2025-05-31 22:18:08', 'done', 0, 0),
(99, '02000152695', 'Domdom Jr', 'Bobby', NULL, '', '2025-09-02', 'domdomjr.152695@naga.sti.edu.ph', '', 'Male', '0915-422-3266', 'HUMSS', 'Grade 11', 'B', 'asdasdasdsad', 'Bobby V Domdom Jr', '0912-326-4623', 'Sibling', '2025-09-02 06:02:25', '2025-09-02 06:02:25', '2025-09-02 14:02:25', 'pending', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  `action` text NOT NULL,
  `log_time` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_logs`
--

INSERT INTO `user_logs` (`id`, `user_id`, `username`, `role`, `action`, `log_time`) VALUES
(43, 0, 'staf', 'N/A', 'Failed login attempt', '2025-06-01 15:58:16'),
(44, 4, 'staff', 'staff', 'User logged in', '2025-06-01 15:58:21'),
(45, 4, 'staff', 'staff', 'User logged in', '2025-06-01 16:03:48'),
(46, 8, NULL, NULL, 'User reset their password', '2025-06-01 16:09:18'),
(47, 4, 'staff', 'staff', 'User logged in', '2025-06-01 17:11:37'),
(48, 4, 'staff', 'staff', 'User logged in', '2025-06-01 17:14:57'),
(49, 4, 'staff', 'staff', 'User logged in', '2025-06-01 17:15:23'),
(50, 0, 'superadmin', 'N/A', 'Failed login attempt', '2025-06-01 17:17:15'),
(51, 3, 'admin', 'admin', 'User logged in', '2025-06-01 17:17:20'),
(52, 8, NULL, NULL, 'User reset their password', '2025-06-01 17:18:32'),
(53, 8, NULL, NULL, 'User reset their password', '2025-06-01 17:23:17'),
(54, 8, NULL, NULL, 'User reset their password', '2025-06-01 17:24:55'),
(55, 8, NULL, NULL, 'User reset their password', '2025-06-01 17:27:48'),
(56, 8, NULL, NULL, 'User reset their password', '2025-06-01 17:50:10'),
(57, 8, NULL, NULL, 'User reset their password', '2025-06-01 17:51:07'),
(58, 8, NULL, NULL, 'User reset their password', '2025-06-01 17:51:23'),
(59, 8, NULL, NULL, 'User reset their password', '2025-06-01 17:51:34'),
(60, 8, NULL, NULL, 'User reset their password', '2025-06-01 17:51:37'),
(61, 3, NULL, NULL, 'User reset their password', '2025-06-01 17:51:51'),
(62, 8, NULL, NULL, 'User reset their password', '2025-06-01 17:52:11'),
(63, 8, NULL, NULL, 'User reset their password', '2025-06-01 17:52:20'),
(64, 8, NULL, NULL, 'User reset their password', '2025-06-01 17:52:30'),
(65, 10, 'bobbydomdomjr', 'staff', 'User logged in', '2025-06-01 17:54:04'),
(66, 10, 'bobbydomdomjr', 'staff', 'User logged in', '2025-06-01 17:55:12'),
(67, 10, 'bobbydomdomjr', 'staff', 'User logged in', '2025-06-01 17:55:47'),
(68, 3, 'admin', 'admin', 'User logged in', '2025-09-02 14:00:13'),
(69, 4, 'staff', 'staff', 'User logged in', '2025-09-02 14:06:45'),
(70, 0, 'saz', 'N/A', 'Failed login attempt', '2025-09-02 14:22:40'),
(71, 0, 'asd', 'N/A', 'Failed login attempt', '2025-09-02 14:23:28'),
(72, 0, 'asd', 'N/A', 'Failed login attempt', '2025-09-02 14:24:18'),
(73, 0, 'asd', 'N/A', 'Failed login attempt', '2025-09-02 14:24:37'),
(74, 0, 'asd', 'N/A', 'Failed login attempt', '2025-09-02 14:24:50'),
(75, 0, 'asd', 'N/A', 'Failed login attempt', '2025-09-02 14:26:14'),
(76, 0, 'asd', 'N/A', 'Failed login attempt', '2025-09-02 14:26:33'),
(77, 0, 'asd', 'N/A', 'Failed login attempt', '2025-09-02 14:27:44'),
(78, 0, 'asd', 'N/A', 'Failed login attempt', '2025-09-02 14:27:57'),
(79, 4, 'staff', 'staff', 'User logged in', '2025-09-02 14:28:03'),
(80, 0, 'admin', 'N/A', 'Failed login attempt', '2025-09-02 14:38:35'),
(81, 3, 'admin', 'admin', 'User logged in', '2025-09-02 14:38:40'),
(82, 0, 'admin', 'N/A', 'Failed login attempt', '2025-09-02 14:39:07'),
(83, 3, 'admin', 'admin', 'User logged in', '2025-09-02 14:39:11'),
(84, 4, 'staff', 'staff', 'User logged in', '2025-09-02 14:40:06');

-- --------------------------------------------------------

--
-- Table structure for table `user_permissions`
--

CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_registration`
--
ALTER TABLE `student_registration`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `studentno` (`studentno`);

--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_permissions`
--
ALTER TABLE `user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student_registration`
--
ALTER TABLE `student_registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `user_permissions`
--
ALTER TABLE `user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_permissions`
--
ALTER TABLE `user_permissions`
  ADD CONSTRAINT `user_permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `admin` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
