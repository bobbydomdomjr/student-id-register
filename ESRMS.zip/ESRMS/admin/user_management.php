<?php
// admin/user_management.php
require_once __DIR__ . '/../includes/init.php';

// Load all admin/staff (exclude superadmin)
$sql = "SELECT id, username, role
        FROM admin
        WHERE role IN ('admin','staff')
        ORDER BY username";
$stmt = $conn->query($sql);
$accounts = $stmt->fetch_all(MYSQLI_ASSOC);

// Feedback messages
$flash = $_SESSION['flash'] ?? null;
// Do NOT unset here, JS will handle it after reading
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>User Management</title>
    <!-- Only one Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet" />

    <style>
        body { margin: 0; }
        .home-section { margin-left: 250px; padding: 2rem; background: #f8f9fa; min-height: 100vh; transition: margin-left .3s; }
        .sidebar.open ~ .home-section { margin-left: 80px; }
        @media (max-width: 768px) {
            .sidebar { width: 0 !important; }
            .sidebar.open { width: 250px; }
            .home-section { margin-left: 0; }
        }
    </style>
</head>
<body>

<!-- Toast container -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 1100;">
  <div id="flashToast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body" id="toastMessage"></div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/sidebar.php'; ?>

<section class="home-section p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>User Management</h2>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
            <i class="fas fa-user-plus"></i> Add Account
        </button>
    </div>

    <div class="mb-3">
        <input id="searchInput" type="text" class="form-control" placeholder="Search username…" />
    </div>

    <div class="row g-3" id="accountsContainer">
        <?php foreach ($accounts as $a): ?>
            <div class="col-md-4 account-card" data-username="<?= strtolower(htmlspecialchars($a['username'])) ?>">
                <div class="card shadow-sm">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="mb-1"><?= htmlspecialchars($a['username']) ?></h5>
                            <small class="text-muted"><?= ucfirst(htmlspecialchars($a['role'])) ?></small>
                        </div>
                        <div class="btn-group">
    <button class="btn btn-sm btn-outline-warning editBtn" data-id="<?= (int)$a['id'] ?>" data-bs-toggle="modal" data-bs-target="#editModal">
        <i class="fas fa-edit"></i>
    </button>
    <button class="btn btn-sm btn-outline-info permBtn" data-id="<?= (int)$a['id'] ?>" data-bs-toggle="modal" data-bs-target="#permModal">
        <i class="fas fa-shield-alt"></i>
    </button>
    <button class="btn btn-sm btn-outline-secondary resetBtn" data-id="<?= (int)$a['id'] ?>">
        <i class="fas fa-key"></i>
    </button>
    <button class="btn btn-sm btn-outline-danger deleteBtn" data-id="<?= (int)$a['id'] ?>">
        <i class="fas fa-trash"></i>
    </button>
</div>

                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="add_account.php" method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Account</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="addUsername" class="form-label">Username</label>
                    <input id="addUsername" name="username" class="form-control" required />
                </div>
                <div class="mb-3">
                    <label for="addPassword" class="form-label">Password</label>
                    <input id="addPassword" name="password" type="password" class="form-control" required />
                </div>
                <div class="mb-3">
                    <label for="addRole" class="form-label">Role</label>
                    <select id="addRole" name="role" class="form-select" required>
                        <option value="admin">Admin</option>
                        <option value="staff">Staff</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="submit">Create</button>
            </div>
        </form>
    </div>
</div>

<!-- Permissions Modal -->
<div class="modal fade" id="permModal" tabindex="-1" aria-labelledby="permModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="permForm" method="POST" action="update_permissions.php" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="permModalLabel">Manage Permissions</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="permBody">

        <!-- Dynamically filled with checkboxes -->
        <input type="hidden" name="user_id" id="permUserId" />
        <div id="permCheckboxes" class="form-group"></div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Save Permissions</button>
      </div>
    </form>
  </div>
</div>


<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="edit_account.php" method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Account</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="id" id="edit-id" />
                <div class="mb-3">
                    <label for="edit-username" class="form-label">Username</label>
                    <input id="edit-username" name="username" class="form-control" required />
                </div>
                <div class="mb-3">
                    <label for="edit-password" class="form-label">New Password <small>(leave blank to keep)</small></label>
                    <input id="edit-password" name="password" type="password" class="form-control" />
                </div>
                <div class="mb-3">
                    <label for="edit-role" class="form-label">Role</label>
                    <select id="edit-role" name="role" class="form-select" required>
                        <option value="admin">Admin</option>
                        <option value="staff">Staff</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-success" type="submit">Update</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Client-side search
    document.getElementById('searchInput').addEventListener('input', e => {
        const q = e.target.value.toLowerCase();
        document.querySelectorAll('.account-card').forEach(card => {
            card.style.display = card.dataset.username.includes(q) ? '' : 'none';
        });
    });

    // Edit button → fetch JSON
    document.querySelectorAll('.editBtn').forEach(btn => {
        btn.onclick = () => {
            fetch(`edit_account.php?id=${btn.dataset.id}`)
                .then(r => r.json())
                .then(u => {
                    document.getElementById('edit-id').value = u.id;
                    document.getElementById('edit-username').value = u.username;
                    document.getElementById('edit-role').value = u.role;
                    document.getElementById('edit-password').value = '';
                });
        };
    });

    // Delete & Reset (simple confirm + redirect)
    document.querySelectorAll('.deleteBtn').forEach(btn => {
        btn.onclick = () => {
            if (confirm('Delete this account?')) {
                window.location = `delete_account.php?id=${btn.dataset.id}`;
            }
        };
    });
    document.querySelectorAll('.resetBtn').forEach(btn => {
        btn.onclick = () => {
            if (confirm('Reset password to role + "123"?')) {
                window.location = `reset_password.php?id=${btn.dataset.id}`;
            }
        };
    });

    // Toast notification
    document.addEventListener('DOMContentLoaded', () => {
        <?php if ($flash): ?>
            const flashType = <?= json_encode($flash['type']) ?>;
            const flashMsg = <?= json_encode($flash['msg']) ?>;
            const toastEl = document.getElementById('flashToast');
            const toastMsg = document.getElementById('toastMessage');

            toastEl.classList.remove('text-bg-success', 'text-bg-danger', 'text-bg-warning', 'text-bg-info');
            if (flashType === 'success') toastEl.classList.add('text-bg-success');
            else if (flashType === 'danger') toastEl.classList.add('text-bg-danger');
            else if (flashType === 'warning') toastEl.classList.add('text-bg-warning');
            else toastEl.classList.add('text-bg-info');

            toastMsg.textContent = flashMsg;

            const bsToast = new bootstrap.Toast(toastEl, { delay: 4000 });
            bsToast.show();

            <?php unset($_SESSION['flash']); ?>
        <?php endif; ?>
    });

    //permissions
    
    document.querySelectorAll('.permBtn').forEach(btn => {
    btn.onclick = () => {
        const userId = btn.dataset.id;
        document.getElementById('permUserId').value = userId;

        fetch(`fetch_permissions.php?user_id=${userId}`)
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
                return;
            }
            const container = document.getElementById('permCheckboxes');
            container.innerHTML = ''; // clear

            data.all_permissions.forEach(p => {
                const checked = data.user_permissions.includes(p.id) ? 'checked' : '';
                const html = `
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="permissions[]" value="${p.id}" id="perm-${p.id}" ${checked}>
                        <label class="form-check-label" for="perm-${p.id}">
                            ${p.name} <small class="text-muted">${p.description || ''}</small>
                        </label>
                    </div>
                `;
                container.insertAdjacentHTML('beforeend', html);
            });
        });
    };
});

</script>

</body>
</html>
