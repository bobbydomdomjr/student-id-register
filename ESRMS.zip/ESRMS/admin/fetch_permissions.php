<?php
require_once __DIR__ . '/../includes/init.php';

$user_id = intval($_GET['user_id'] ?? 0);
if ($user_id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid user ID']);
    exit;
}

// Fetch all permissions
$all = $conn->query("SELECT id, name, description FROM permissions ORDER BY name")->fetch_all(MYSQLI_ASSOC);

// Fetch user permissions
$stmt = $conn->prepare("SELECT permission_id FROM user_permissions WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();

$user_perms = [];
while ($row = $res->fetch_assoc()) {
    $user_perms[] = $row['permission_id'];
}

echo json_encode([
    'all_permissions' => $all,
    'user_permissions' => $user_perms,
]);
