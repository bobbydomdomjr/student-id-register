<?php
session_start();
require_once('../db.php');$sql = "SELECT id, username FROM users WHERE role = 'staff'";
$result = $conn->query($sql);

$sender_id = intval($_POST['sender_id']);
$receiver_id = intval($_POST['receiver_id']);
$message = $conn->real_escape_string($_POST['message']);

if (!empty($message)) {
    $sql = "INSERT INTO messages (sender_id, receiver_id, message) VALUES ($sender_id, $receiver_id, '$message')";
    $conn->query($sql);
}