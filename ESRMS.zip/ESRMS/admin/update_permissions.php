<?php
require_once __DIR__ . '/../includes/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method Not Allowed');
}

if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Invalid CSRF token'];
    header('Location: user_management.php');
    exit;
}

$user_id = (int)($_POST['user_id'] ?? 0);
$permissions = $_POST['permissions'] ?? [];

if ($user_id <= 0) {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Invalid user ID'];
    header('Location: user_management.php');
    exit;
}

$conn->begin_transaction();

try {
    // Delete existing permissions
    $stmt = $conn->prepare("DELETE FROM user_permissions WHERE user_id = ?");
    $stmt->bind_param('i', $user_id);
    if (!$stmt->execute()) {
        throw new Exception("Delete failed: " . $stmt->error);
    }
    $stmt->close();

    // Insert new permissions
    if (!empty($permissions)) {
        $stmt = $conn->prepare("INSERT INTO user_permissions (user_id, permission) VALUES (?, ?)");
        foreach ($permissions as $perm) {
            $perm = trim($perm);
            if ($perm === '') continue;
            $stmt->bind_param('is', $user_id, $perm);
            if (!$stmt->execute()) {
                throw new Exception("Insert failed: " . $stmt->error);
            }
        }
        $stmt->close();
    }

    $conn->commit();
    $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Permissions updated'];
} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Failed to update permissions: ' . $e->getMessage()];
}

header('Location: user_management.php');
exit;
