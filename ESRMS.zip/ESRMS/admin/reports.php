<?php
// admin/reports.php
require_once __DIR__ . '/../includes/init.php';

// Fetch logs from database
$sql = "SELECT * FROM user_logs ORDER BY log_time DESC"; // Adjust table/column names accordingly
$result = $conn->query($sql);

// 1) Summary counts
$today      = date('Y-m-d');
$totalAll   = getCount($conn, "SELECT COUNT(*) FROM student_registration");
$totalToday = getCount($conn, "SELECT COUNT(*) FROM student_registration WHERE DATE(registration_date) = '$today'");
$pending    = getCount($conn, "SELECT COUNT(*) FROM student_registration WHERE status='pending'");
$processing = getCount($conn, "SELECT COUNT(*) FROM student_registration WHERE status='processing'");
$done       = getCount($conn, "SELECT COUNT(*) FROM student_registration WHERE status='done'");
$noshow     = getCount($conn, "SELECT COUNT(*) FROM student_registration WHERE status='no-show'");

// 2) Status filter
$allowed = ['all','pending','processing','done','no-show'];
$status  = (isset($_GET['status']) && in_array($_GET['status'], $allowed))
    ? $_GET['status']
    : 'all';

// 3) Table data
if ($status === 'all') {
    $stmt = $conn->prepare("SELECT * FROM student_registration ORDER BY registration_date DESC");
} else {
    $stmt = $conn->prepare("SELECT * FROM student_registration WHERE status = ? ORDER BY registration_date DESC");
    $stmt->bind_param('s', $status);
}
$stmt->execute();
$regs = $stmt->get_result();

// 4) Logs
$logRes = $conn->query("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 50");

// 5) Course-by-status
$courseByStatus = [];
foreach (array_merge(['all'], $allowed) as $st) {
    $courseByStatus[$st] = [];
}
$rs = $conn->query("
  SELECT status, course, COUNT(*) AS cnt
    FROM student_registration
   GROUP BY status, course
");
while ($r = $rs->fetch_assoc()) {
    $courseByStatus[$r['status']][$r['course']] = (int)$r['cnt'];
}
foreach ($courseByStatus as $st => $arr) {
    if ($st==='all') continue;
    foreach ($arr as $c => $cnt) {
        $courseByStatus['all'][$c] = ($courseByStatus['all'][$c] ?? 0) + $cnt;
    }
}

// 6) Monthly-by-status
$monthlyByStatus = [];
foreach (array_merge(['all'], $allowed) as $st) {
    $monthlyByStatus[$st] = [];
}
$rs2 = $conn->query("
  SELECT status, DATE_FORMAT(registration_date,'%Y-%m') AS m, COUNT(*) AS cnt
    FROM student_registration
   GROUP BY status, m
   ORDER BY m
");
while ($r = $rs2->fetch_assoc()) {
    $monthlyByStatus[$r['status']][$r['m']] = (int)$r['cnt'];
}
foreach ($monthlyByStatus as $st => $arr) {
    if ($st==='all') continue;
    foreach ($arr as $m => $cnt) {
        $monthlyByStatus['all'][$m] = ($monthlyByStatus['all'][$m] ?? 0) + $cnt;
    }
}

// 7) Status breakdown for chart
$statusChartData = [
    ['label'=>'Waiting',    'count'=>$pending,    'color'=>'#ffc107','raw'=>'pending'],
    ['label'=>'Processing', 'count'=>$processing, 'color'=>'#28a745','raw'=>'processing'],
    ['label'=>'Completed',  'count'=>$done,       'color'=>'#17a2b8','raw'=>'done'],
    ['label'=>'No-Show',    'count'=>$noshow,     'color'=>'#dc3545','raw'=>'no-show'],
];

// 8) Status label map for table
$statusLabelMap = [
    'pending'    => 'Waiting',
    'processing' => 'Processing',
    'done'       => 'Completed',
    'no-show'    => 'No-Show'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Reports & Logs</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body { margin:0; }
        .home-section { margin-left:250px; padding:2rem; background:#f8f9fa; min-height:100vh; transition: margin-left .3s; }
        .sidebar.open ~ .home-section { margin-left:80px; }
        @media (max-width:768px) { .sidebar{width:0!important;} .sidebar.open{width:250px!important;} .home-section{margin-left:0;} }
        .stat-card { border-radius:16px; box-shadow:0 4px 16px rgba(0,0,0,.1); }
        .stat-icon { font-size:1.5rem; opacity:.8; }
        .chart-container { max-width:700px; }
                .chart-container { max-width:700px; }

        .chart-container {
  position: relative;
  width: 100%;
  height: 400px;
}

@media (max-width: 576px) {
  .chart-container {
    height: 300px;
  }
}
    </style>
</head>
<body>
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<section class="home-section p-4">
    <h2>Reports &amp; Logs</h2>
    <hr>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-4" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#reportsTab" role="tab">Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#logsTab" role="tab">Logs</a>
        </li>
    </ul>

    <div class="tab-content">
        <!-- REPORTS -->
        <div class="tab-pane fade show active text-center" id="reportsTab" role="tabpanel">
            <!-- Summary Cards -->
            <div class="row g-3 mb-4 justify-content-center">
                <?php foreach ([
                                   ['label'=>'Total','count'=>$totalAll,'bg'=>'primary','icon'=>'users'],
                                   ['label'=>'Today','count'=>$totalToday,'bg'=>'secondary','icon'=>'calendar-day'],
                                   ['label'=>'Waiting','count'=>$pending,'bg'=>'warning','icon'=>'hourglass-start'],
                                   ['label'=>'Processing','count'=>$processing,'bg'=>'success','icon'=>'spinner'],
                                   ['label'=>'Completed','count'=>$done,'bg'=>'info','icon'=>'check-circle'],
                                   ['label'=>'No-Show','count'=>$noshow,'bg'=>'danger','icon'=>'user-times'],
                               ] as $c): ?>
                    <div class="col-6 col-md-2">
                        <div class="card text-white bg-<?= $c['bg'] ?> stat-card p-3">
                            <div><i class="fas fa-<?= $c['icon'] ?> stat-icon"></i> <?= $c['label'] ?></div>
                            <div class="h3"><?= $c['count'] ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Registrations Table Filter -->
            <div class="d-flex justify-content-center mb-3">
                <label class="me-2">Status:</label>
                <select id="statusFilter" class="form-select w-auto">
                    <?php foreach ($allowed as $opt): ?>
                        <option value="<?= $opt ?>" <?= $status===$opt?'selected':'' ?>>
                            <?= $opt==='all'?'All':ucfirst($statusLabelMap[$opt] ?? $opt) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Registrations Table -->
            <div class="table-responsive mb-5">
                <table class="table table-striped">
                    <thead class="table-dark text-center">
                    <tr><th>#</th><th>Student No.</th><th>Name</th><th>Status</th><th>When</th></tr>
                    </thead>
                    <tbody>
                    <?php $i=1; while($r=$regs->fetch_assoc()):
                        $raw = strtolower($r['status']);
                        $disp = $statusLabelMap[$raw] ?? ucfirst($raw);
                        ?>
                        <tr>
                            <td><?= $i++ ?></td>
                            <td><?= htmlspecialchars($r['studentno']) ?></td>
                            <td><?= htmlspecialchars("{$r['lastname']}, {$r['firstname']}") ?></td>
                            <td><?= $disp ?></td>
                            <td><?= $r['registration_date'] ?></td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

<div class="card mt-4">
  <div class="card-body">
    <ul class="nav nav-tabs mb-3" id="chartTabs" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link active" id="status-tab" data-bs-toggle="tab" data-bs-target="#statusTabPane" type="button" role="tab">
          Status Breakdown
        </button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="course-tab" data-bs-toggle="tab" data-bs-target="#courseTabPane" type="button" role="tab">
          Course Enrollment
        </button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="monthly-tab" data-bs-toggle="tab" data-bs-target="#monthlyTabPane" type="button" role="tab">
          Monthly Registrations
        </button>
      </li>
    </ul>

    <div class="tab-content" id="chartTabsContent">

      <!-- Status Breakdown Tab -->
      <div class="tab-pane fade show active" id="statusTabPane" role="tabpanel">
        <div class="d-flex justify-content-center mb-3">
          <div class="chart-container" style="width: 100%;">
            <canvas id="statusChart"></canvas>
          </div>
        </div>
      </div>

      <!-- Course Enrollment Tab -->
      <div class="tab-pane fade" id="courseTabPane" role="tabpanel">
        <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
          <label class="me-1 mb-0">Status:</label>
          <select id="courseStatusFilter" class="form-select form-select-sm w-auto">
            <?php foreach ($allowed as $opt): ?>
              <option value="<?= $opt ?>" <?= $status===$opt?'selected':'' ?>>
                <?= $opt==='all'?'All':ucfirst($statusLabelMap[$opt] ?? $opt) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <label class="me-1 mb-0">Course:</label>
          <select id="courseFilter" class="form-select form-select-sm w-auto">
            <option value="">All</option>
            <?php foreach (array_keys($courseByStatus['all']) as $c): ?>
              <option><?= htmlspecialchars($c) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="d-flex justify-content-center">
          <div class="chart-container" style="width: 100%;">
            <canvas id="courseChart"></canvas>
            <p id="courseNoData" class="text-center text-muted mt-2" style="display:none;">No data.</p>
          </div>
        </div>
      </div>

      <!-- Monthly Registrations Tab -->
      <div class="tab-pane fade" id="monthlyTabPane" role="tabpanel">
        <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
          <label class="me-1 mb-0">Status:</label>
          <select id="monthStatusFilter" class="form-select form-select-sm w-auto">
            <?php foreach ($allowed as $opt): ?>
              <option value="<?= $opt ?>" <?= $status===$opt?'selected':'' ?>>
                <?= $opt==='all'?'All':ucfirst($statusLabelMap[$opt] ?? $opt) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <label class="me-1 mb-0">Month:</label>
          <input type="month" id="monthFilter" class="form-control form-control-sm w-auto">
        </div>
        <div class="d-flex justify-content-center">
          <div class="chart-container" style="width: 100%;">
            <canvas id="monthlyChart"></canvas>
            <p id="monthlyNoData" class="text-center text-muted mt-2" style="display:none;">No data.</p>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

    </div>
    <!-- LOGS -->
<div class="tab-pane fade" id="logsTab" role="tabpanel" aria-labelledby="logs-tab">
    <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <input type="text" id="logSearch" class="form-control" placeholder="Search logs...">
    </div>
    <div>
        <button id="exportCsvBtn" class="btn btn-outline-primary btn-sm">Export CSV</button>
    </div>
</div>
    <h5 class="mb-3">Recent Notifications</h5>

    <div class="table-responsive">
        <?php $logsArray = [];
if ($result && $result->num_rows > 0) {
    while ($log = $result->fetch_assoc()) {
        $logsArray[] = $log;
    }
}
// JSON encode the logs for JS use
$logsJson = json_encode($logsArray);
?>
<div id="logsData" data-logs='<?= htmlspecialchars($logsJson, ENT_QUOTES, 'UTF-8') ?>' style="display:none;"></div>
  

        <table class="table table-striped table-hover table-bordered align-middle">
    <thead class="table-dark">
        <tr>
            <th scope="col">User ID</th>
            <th scope="col">Username</th>
            <th scope="col">Role</th>
            <th scope="col">Action</th>
            <th scope="col">Timestamp</th>
        </tr>
    </thead>
    <tbody id="logsTableBody">
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($log = $result->fetch_assoc()): ?>
                <?php 
                    $role = strtolower(trim($log['role']));
                    $badgeClass = 'bg-secondary'; // default color
                    if ($role === 'admin') $badgeClass = 'bg-danger';
                    else if ($role === 'staff') $badgeClass = 'bg-primary';
                ?>
                <tr>
                    <td><?= htmlspecialchars($log['user_id']) ?></td>
                    <td><?= htmlspecialchars($log['username']) ?></td>
                    <td>
                        <span class="badge <?= $badgeClass ?>">
                            <?= htmlspecialchars(ucfirst($role)) ?>
                        </span>
                    </td>
                    <td><?= htmlspecialchars($log['action']) ?></td>
                    <td><?= htmlspecialchars(date('M d, Y H:i:s', strtotime($log['log_time']))) ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="5" class="text-center fw-semibold">No logs found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>


    </div>
</div>

</section>

<!-- Bootstrap & Chart.js -->
<script src="./../dist/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns/dist/chartjs-adapter-date-fns.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Table filter
    document.getElementById('statusFilter').onchange = function(){
        window.location = 'reports.php?status=' + this.value;
    };

    // Status Breakdown Chart
    const scData = <?= json_encode($statusChartData) ?>;
    new Chart(document.getElementById('statusChart'), {
        type: 'bar',
        data: {
            labels: scData.map(d=>d.label),
            datasets: [{
                label: 'Count',
                data: scData.map(d=>d.count),
                backgroundColor: scData.map(d=>d.color)
            }]
        },
        options: { responsive:true, plugins:{legend:{display:false}}, scales:{y:{beginAtZero:true}} }
    });

    // Course Chart
    const courseChart = new Chart(document.getElementById('courseChart'), {
        type: 'pie',
        data: { labels:[], datasets:[{ data:[], backgroundColor:[] }] }
    });
    function updateCourseChart(){
        const st = document.getElementById('courseStatusFilter').value;
        const cf = document.getElementById('courseFilter').value;
        const obj=<?= json_encode($courseByStatus) ?>[st]||{};
        const labels=[], data=[];
        for(let c in obj) if(!cf||cf===c){labels.push(c);data.push(obj[c]);}
        if(!data.length){
            courseChart.canvas.style.display='none';
            document.getElementById('courseNoData').style.display='block';
        } else {
            courseChart.canvas.style.display='block';
            document.getElementById('courseNoData').style.display='none';
            courseChart.data.labels=labels;
            courseChart.data.datasets[0].data=data;
            courseChart.data.datasets[0].backgroundColor=labels.map((_,i)=>['#007bff','#28a745','#ffc107','#dc3545','#17a2b8'][i%5]);
            courseChart.update();
        }
    }
    document.getElementById('courseStatusFilter').onchange=updateCourseChart;
    document.getElementById('courseFilter').onchange=updateCourseChart;
    updateCourseChart();

    // Monthly Chart
    const monthlyChart = new Chart(document.getElementById('monthlyChart'), {
        type:'line',
        data:{labels:[],datasets:[{label:'Regs',data:[],fill:true}]},
        options:{
            responsive:true,
            scales:{
                x:{type:'time',time:{parser:'yyyy-MM',unit:'month',tooltipFormat:'yyyy-MM'}},
                y:{beginAtZero:true}
            }
        }
    });
    function updateMonthlyChart(){
        const st = document.getElementById('monthStatusFilter').value;
        const mf = document.getElementById('monthFilter').value;
        const obj=<?= json_encode($monthlyByStatus) ?>[st]||{};
        const labels=[], data=[];
        for(let m in obj) if(!mf||m.startsWith(mf)){labels.push(m);data.push(obj[m]);}
        if(!data.length){
            monthlyChart.canvas.style.display='none';
            document.getElementById('monthlyNoData').style.display='block';
        } else {
            monthlyChart.canvas.style.display='block';
            document.getElementById('monthlyNoData').style.display='none';
            monthlyChart.data.labels=labels;
            monthlyChart.data.datasets[0].data=data;
            monthlyChart.update();
        }
    }
    document.getElementById('monthStatusFilter').onchange=updateMonthlyChart;
    document.getElementById('monthFilter').onchange=updateMonthlyChart;
    updateMonthlyChart();
</script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const logsDataDiv = document.getElementById('logsData');
    const logs = JSON.parse(logsDataDiv.getAttribute('data-logs'));
    const tbody = document.getElementById('logsTableBody');
    const searchInput = document.getElementById('logSearch');
    const exportBtn = document.getElementById('exportCsvBtn');

    const rowsPerPage = 10;
    let currentPage = 1;
    let filteredLogs = [...logs];

    function renderTablePage(page) {
        tbody.innerHTML = "";
        const start = (page - 1) * rowsPerPage;
        const end = start + rowsPerPage;
        const pageLogs = filteredLogs.slice(start, end);

        if (pageLogs.length === 0) {
            tbody.innerHTML = `<tr><td colspan="6" class="text-center">No logs found.</td></tr>`;
            return;
        }

        pageLogs.forEach(log => {
            const row = document.createElement('tr');
            row.innerHTML = `
                
                <td>${escapeHtml(log.user_id)}</td>
                <td>${escapeHtml(log.username)}</td>
                <td>${escapeHtml(log.role)}</td>
                <td>${escapeHtml(log.action)}</td>
                <td>${escapeHtml(log.log_time)}</td>
            `;
            tbody.appendChild(row);
        });

        renderPagination();
    }

    function renderPagination() {
        // Remove old pagination if exists
        let oldPagination = document.getElementById('logsPagination');
        if (oldPagination) oldPagination.remove();

        const pagination = document.createElement('nav');
        pagination.id = 'logsPagination';
        pagination.className = 'mt-3';

        const ul = document.createElement('ul');
        ul.className = 'pagination justify-content-center';

        const totalPages = Math.ceil(filteredLogs.length / rowsPerPage);

        for (let i = 1; i <= totalPages; i++) {
            const li = document.createElement('li');
            li.className = 'page-item' + (i === currentPage ? ' active' : '');
            const a = document.createElement('a');
            a.className = 'page-link';
            a.href = '#';
            a.textContent = i;
            a.addEventListener('click', function (e) {
                e.preventDefault();
                currentPage = i;
                renderTablePage(currentPage);
            });
            li.appendChild(a);
            ul.appendChild(li);
        }

        pagination.appendChild(ul);
        tbody.parentElement.after(pagination);
    }

    function escapeHtml(text) {
        if (typeof text !== 'string') return text;
        return text.replace(/[&<>"']/g, function (match) {
            return ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#39;'
            })[match];
        });
    }

    // Search handler
    searchInput.addEventListener('input', function () {
        const query = this.value.trim().toLowerCase();
        filteredLogs = logs.filter(log => {
            return Object.values(log).some(val =>
                String(val).toLowerCase().includes(query)
            );
        });
        currentPage = 1;
        renderTablePage(currentPage);
    });

        // Export CSV handler
        exportBtn.addEventListener('click', function () {
            let csvContent = "data:text/csv;charset=utf-8,";
            csvContent += "ID,User ID,Username,Role,Action,Timestamp\n";

            filteredLogs.forEach(log => {
                const row = [
                   
                    log.user_id,
                    `"${log.username.replace(/"/g, '""')}"`,
                    `"${log.role.replace(/"/g, '""')}"`,
                    `"${log.action.replace(/"/g, '""')}"`,
                    `"${log.log_time.replace(/"/g, '""')}"`
                ];
                csvContent += row.join(",") + "\n";
            });

            const encodedUri = encodeURI(csvContent);
            const link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", "logs_export.csv");
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        });

        // Initial render
        renderTablePage(currentPage);
    });
</script>

</body>
</html>
