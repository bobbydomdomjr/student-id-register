<?php
session_start();

require '../db.php'; // your DB connection file
require '../logs/log_action.php';

// Log before unsetting session variables
$user_id = $_SESSION['user_id'] ?? null;
$username = $_SESSION['username'] ?? null;
$role = $_SESSION['role'] ?? null;

if ($user_id !== null) {
    log_action($conn, $user_id, $username, $role, "User logged out");
}

// Now clear session data
$_SESSION = [];

// Destroy session cookie if it exists
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

// Destroy session
session_destroy();

// Redirect to login page with success message
header("Location: ./login/index.php?logout=success");
exit();
?>
