<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit();
}

include('../db.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Fetch current queuing status safely
    $stmt = $conn->prepare("SELECT queuing_enabled FROM settings WHERE id = 1 LIMIT 1");
    $stmt->execute();
    $result = $stmt->get_result();
    $config = $result->fetch_assoc();
    $stmt->close();

    if ($config === null) {
        $_SESSION['error_message'] = "Configuration not found.";
        header("Location: queue_manager.php");
        exit();
    }

    // Toggle status
    $newStatus = ($config['queuing_enabled'] == 1) ? 0 : 1;

    // Update the status
    $updateStmt = $conn->prepare("UPDATE settings SET queuing_enabled = ? WHERE id = 1");
    $updateStmt->bind_param("i", $newStatus);
    if ($updateStmt->execute()) {
        $_SESSION['success_message'] = $newStatus ? 'Queuing System Enabled.' : 'Queuing System Disabled.';
    } else {
        $_SESSION['error_message'] = 'Failed to update queuing system status.';
    }
    $updateStmt->close();

//    header("Location: queue_manager.php");
        header("Location: queue_manager.php?toggle=" . ($new ? 'on' : 'off'));
    exit();
}

// If accessed without POST, redirect
header("Location: queue_manager.php");
exit();
?>
