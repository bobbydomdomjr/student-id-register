<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include('../db.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fetch student statistics
$sql_course = "SELECT course, COUNT(*) AS count FROM student_registration GROUP BY course";
$result_course = $conn->query($sql_course) or die("Error in SQL (course): " . $conn->error);

$sql_monthly = "SELECT DATE_FORMAT(dob, '%Y-%m') AS month, COUNT(*) AS count FROM student_registration GROUP BY month ORDER BY month";
$result_monthly = $conn->query($sql_monthly) or die("Error in SQL (monthly): " . $conn->error);

$course_data = [];
$monthly_data = [];

while ($row = $result_course->fetch_assoc()) {
    $course_data[] = ['course' => $row['course'], 'count' => $row['count']];
}

while ($row = $result_monthly->fetch_assoc()) {
    $monthly_data[] = ['month' => $row['month'], 'count' => $row['count']];
}

// Pagination setup
$limit = 10; // number of results per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Search functionality
$search_term = isset($_GET['search']) ? $_GET['search'] : '';

// Query to fetch student data with search
$sql_students = "SELECT * FROM student_registration WHERE CONCAT(firstname, ' ', lastname, ' ', course) LIKE '%$search_term%' LIMIT $limit OFFSET $offset";
$result_students = $conn->query($sql_students) or die("Error in SQL (students): " . $conn->error);

// Count total students for pagination
$sql_count = "SELECT COUNT(*) AS total FROM student_registration WHERE CONCAT(firstname, ' ', lastname, ' ', course) LIKE '%$search_term%'";
$result_count = $conn->query($sql_count);
$total_students = $result_count->fetch_assoc()['total'];
$total_pages = ceil($total_students / $limit);

if (isset($_POST['id'])) {
    $id = (int) $_POST['id']; // Ensure ID is an integer for security
    $query = "SELECT * FROM student_registration WHERE id = $id";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
        echo json_encode($student);
    } else {
        echo json_encode(["error" => "Student not found."]);
    }
}
// Check if there are any success or error messages in the session
$showModal = false;
$message = '';
$type = ''; // 'success' or 'error'

if (isset($_SESSION['success_message'])) {
    $message = $_SESSION['success_message'];
    $type = 'success';
    unset($_SESSION['success_message']);
    $showModal = true;
} elseif (isset($_SESSION['error_message'])) {
    $message = $_SESSION['error_message'];
    $type = 'error';
    unset($_SESSION['error_message']);
    $showModal = true;
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="style.css">
    <!-- Boxicons CDN Link -->
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap 4.3.1 CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Font Awesome -->
  <!-- Font Awesome CSS for icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            display: flex;
            margin: 0;
        }

        #sidebar {
            height: 100vh;
            width: 250px;
            background-color: #343a40;
            color: white;
        }

        #sidebar a {
            padding: 15px;
            text-decoration: none;
            color: white;
            display: block;
        }

        #sidebar a:hover,
        #sidebar a.active {
            background-color: #495057;
        }

        #content {
            flex-grow: 1;
            padding: 20px;
        }

        .btn-sm i {
            margin: 0;
        }

        .modal-content {
            border-radius: 12px;
        }

        #pdf-content {
            display: none;
        }

        .navbar {
            background-color: #343a40;
        }

        #welcomeMessage {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #28a745;
            color: #fff;
            padding: 10px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            display: none;
            z-index: 9999;
        }
        footer {
            margin-top: 100px;
            font-size: 14px;
            color: #495057;
            letter-spacing: 0.5px;
        }
        .status-dropdown {
    padding: 2px 4px;
    font-size: 0.9rem;
        }
    </style>
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-details">
            <i class="bx bxl-angular icon"></i>
            <div class="logo_name">Admin Panel</div>
            <i class="bx bx-menu" id="btn"></i>
        </div>
        <ul class="nav-list">
            <li>
                <a href="dashboard.php">
                    <i class="bx bx-home"></i>
                    <span class="links_name">Home</span>
                </a>
                <span class="tooltip">Home</span>
            </li>
            <li>
                <a href="user_management.php">
                    <i class="bx bx-user-plus"></i>
                    <span class="links_name">User Management</span>
                </a>
                <span class="tooltip">User Management</span>
            </li>
            <li>
                <a href="students.php">
                    <i class="bx bx-group"></i>
                    <span class="links_name">Student Management</span>
                </a>
                <span class="tooltip">Student Management</span>
            </li>
            <li>
                <a href="queue_manager.php">
                    <i class="bx bx-add-to-queue"></i>
                    <span class="links_name">Queue Management</span>
                </a>
                <span class="tooltip">Queue Management</span>
            </li>
            <li>
                <a href="ad_manager.php">
                    <i class="bx bx-play-circle"></i>
                    <span class="links_name">Ads Management</span>
                </a>
                <span class="tooltip">Ads Management</span>
            </li>
            <li>
                <a href="#">
                    <i class="bx bx-file"></i>
                    <span class="links_name">Reports & Logs</span>
                </a>
                <span class="tooltip">Reports & Logs</span>
            </li>
            <li>
                <a href="logout.php" onclick="return confirmLogout()">
                    <i class="bx bx-log-out"></i>
                    <span class="links_name">Logout</span>
                </a>
                <span class="tooltip">Logout</span>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
 <div class=home-section> 
        <div class="text">View Real-time Queue Status</div>
        <!-- Welcome Message Tooltip -->
<hr>

<div class="container-fluid">
            <!-- Student Table -->
            <table class="table table-bordered table-sm align-middle">
                <thead>
                    <tr>
                        <th>Student No.</th>
                        <th>Full Name</th>
                        <th>Course/Year/Block</th>
                        <th>Email Address</th>
                        <th>Registered Date & Time</th>
                        <th>Status</th>
                        <th style="white-space: nowrap;">Actions</th>

                    </tr>
                </thead>
                <tbody>
                    <?php while ($student = $result_students->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $student['studentno']; ?></td>
                            <td><?php echo htmlspecialchars($student['firstname']). ' ' . htmlspecialchars($student['middleinitial']) . ' ' . htmlspecialchars($student['lastname']); ?></td>
                            <td><?php echo htmlspecialchars($student['course']). ' ' . htmlspecialchars($student['yearlevel']) . ' ' . htmlspecialchars($student['block']); ?></td>
                            <td><?php echo htmlspecialchars($student['email']); ?></td>
                            <td><?php echo htmlspecialchars($student['registration_date']); ?></td>
                            <td>
    <?php 
        $status = trim(htmlspecialchars($student['status']));
        $status = ucfirst(strtolower($status));
        
        $statusColors = [
            'Pending' => 'bg-warning',
            'Processing' => 'bg-success',
            'Done' => 'bg-info'
        ];
        $badgeClass = $statusColors[$status] ?? 'bg-secondary';
    ?>
    <span class="badge <?php echo $badgeClass; ?> status-badge" data-id="<?php echo $student['id']; ?>"><?php echo $status; ?></span>
</td>

<td>
    <select class="form-control form-control-sm status-dropdown" data-id="<?php echo $student['id']; ?>">
        <option value="Pending" <?php echo $status == 'Pending' ? 'selected' : ''; ?>>Pending</option>
        <option value="Processing" <?php echo $status == 'Processing' ? 'selected' : ''; ?>>Processing</option>
        <option value="Done" <?php echo $status == 'Done' ? 'selected' : ''; ?>>Done</option>
    </select>
</td>

                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

<!-- Button to Enable/Disable Queuing System -->

    <form method="POST" action="toggle_queuing_system.php" id="queuingSystemForm">
        <button type="submit" class="btn btn-primary" name="toggle_queuing_system" id="toggleQueuingButton">
            <span id="buttonText">
            <?php 
            // Check the current status of the queuing system
            $result = $conn->query("SELECT * FROM settings WHERE id = 1");  // Assuming the settings record has id = 1
            $config = $result->fetch_assoc();
            if ($config['queuing_enabled'] == 1) {
                echo 'Disable';
                echo "<script>document.getElementById('toggleQueuingButton').classList.add('btn-danger');</script>";
            } else {
                echo 'Enable';
                echo "<script>document.getElementById('toggleQueuingButton').classList.add('btn-primary');</script>";
            }
            ?>
            </span>
            <span id="buttonLoader" class="spinner-border spinner-border-sm" role="status" aria-hidden="true" style="display: none;"></span>
        </button>
    </form>

            <!-- Pagination -->
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search_term); ?>">Previous</a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search_term); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search_term); ?>">Next</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
<!-- Toast Notification -->
<div aria-live="polite" aria-atomic="true" style="position: fixed; top: 1rem; right: 1rem; z-index: 1050;">
    <div id="statusToast" class="toast" role="alert" data-delay="3000" style="min-width: 250px;">
        <div class="toast-header">
            <strong class="mr-auto" id="toastTitle">Status</strong>
            <small>Now</small>
            <button type="button" class="ml-2 mb-1 close" data-dismiss="toast">&times;</button>
        </div>
        <div class="toast-body" id="toastBody">
            Status updated successfully!
        </div>
    </div>
</div>

<!-- Toast Container -->
<div id="toast-container" aria-live="polite" aria-atomic="true"
     style="position: fixed; top: 1rem; right: 1rem; z-index: 1050;">
</div>


    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.bundle.min.js"></script>

<script>
    let sidebar = document.querySelector(".sidebar");
    let closeBtn = document.querySelector("#btn");

    closeBtn.addEventListener("click", () => {
        sidebar.classList.toggle("open");
    });

    // Logout Confirmation
    function confirmLogout() {
        return confirm('Are you sure you want to logout?');
    }

    function showToast(title, message, isSuccess = true) {
        $('#toastTitle').text(title);
        $('#toastBody').text(message);

        const toast = $('#statusToast');
        toast.removeClass('bg-success bg-danger text-white');

        if (isSuccess) {
            toast.addClass('bg-success text-white');
        } else {
            toast.addClass('bg-danger text-white');
        }

        toast.toast('show');
    }

    $(document).on('change', '.status-dropdown', function () {
        let newStatus = $(this).val();
        let studentId = $(this).data('id');

        $.ajax({
            url: 'update_status.php',
            method: 'POST',
            data: { id: studentId, status: newStatus },
            success: function (response) {
                try {
                    let res = JSON.parse(response);
                    if (res.success) {
                        showToast('Success', 'Status updated to ' + newStatus);

                        // Update badge text and color
                        let badge = $('.status-badge[data-id="' + studentId + '"]');
                        badge.text(newStatus);

                        let badgeClass = {
                            'Pending': 'bg-warning',
                            'Processing': 'bg-success',
                            'Done': 'bg-info'
                        }[newStatus] || 'bg-secondary';

                        badge.removeClass().addClass('badge status-badge ' + badgeClass);
                    } else {
                        showToast('Error', 'Update failed: ' + res.message, false);
                    }
                } catch (e) {
                    showToast('Error', 'Unexpected error while updating.', false);
                }
            },
            error: function () {
                showToast('Error', 'Failed to update status.', false);
            }
        });
    });

    <?php if ($showModal): ?>
    $(document).ready(function () {
        $('#messageModal').modal('show');
    });
    <?php endif; ?>


    function showToast(title, message, isSuccess = true) {
    const toastId = 'toast' + Date.now();

    const toast = `
        <div id="${toastId}" class="toast" role="alert" aria-live="assertive" aria-atomic="true" data-delay="3000">
            <div class="toast-header ${isSuccess ? 'bg-success' : 'bg-danger'} text-white">
                <strong class="mr-auto">${title}</strong>
                <small>Now</small>
                <button type="button" class="ml-2 mb-1 close text-white" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>
    `;

    $('#toast-container').append(toast);
    $('#' + toastId).toast('show').on('hidden.bs.toast', function () {
        $(this).remove(); // Clean up after dismissal
    });
}

$(document).on('click', '.toggle-status-btn', function () {
    let studentId = $(this).data('id');
    let action = $(this).data('action'); // 'enable' or 'disable'

    $.ajax({
        url: 'toggle_status.php',
        method: 'POST',
        data: { id: studentId, action: action },
        success: function (response) {
            try {
                let res = JSON.parse(response);
                if (res.success) {
                    showToast('Success', 'Student has been ' + action + 'd successfully.');
                    location.reload(); // Or update button text/status dynamically
                } else {
                    showToast('Error', 'Operation failed: ' + res.message, false);
                }
            } catch (e) {
                showToast('Error', 'Unexpected error occurred.', false);
            }
        },
        error: function () {
            showToast('Error', 'Request failed.', false);
        }
    });
});

</script>



</body>

</html>
