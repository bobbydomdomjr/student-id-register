-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 12, 2025 at 10:58 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ocsergs_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `role`) VALUES
(1, 'admin', '$2y$10$/DTt2Q9j6fHnHnKpBNxEWuNo4BAzB9.FCwcHkxSTEfMNpLQSi3aNC', ''),
(2, 'staffUsername', 'hashedPassword', ''),
(0, 'newadmin', '$2y$10$EXAMPLEHASHEDPASSWORDVALUExxxxxxxxxxxxxxxxxxxxxxxxxxx', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`id`, `filename`, `start_time`, `end_time`, `uploaded_at`) VALUES
(59, 'ads/1744241393_OIP.jpg', '2025-04-09 07:29:00', '2025-04-10 07:29:00', '2025-04-09 23:29:53'),
(64, 'ads/1744423182_DataImage17.png', '2025-04-11 09:59:00', '2025-04-12 21:59:00', '2025-04-12 01:59:42'),
(67, 'ads/1744446404__MG_8019.JPG', '2025-04-11 16:26:00', '2025-04-12 16:26:00', '2025-04-12 08:26:44');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('unread','read') DEFAULT 'unread'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `queuing_enabled` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `queuing_enabled`) VALUES
(1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `student_registration`
--

CREATE TABLE `student_registration` (
  `id` int(11) NOT NULL,
  `studentno` varchar(20) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `extname` varchar(10) DEFAULT NULL,
  `middleinitial` varchar(3) DEFAULT NULL,
  `dob` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `phone` varchar(15) NOT NULL,
  `course` varchar(50) NOT NULL,
  `yearlevel` varchar(20) NOT NULL,
  `block` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `contactname` varchar(50) NOT NULL,
  `contactno` varchar(15) NOT NULL,
  `relationship` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `registration_date` datetime DEFAULT current_timestamp(),
  `status` enum('pending','processing','done') NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_registration`
--

INSERT INTO `student_registration` (`id`, `studentno`, `lastname`, `firstname`, `extname`, `middleinitial`, `dob`, `email`, `gender`, `phone`, `course`, `yearlevel`, `block`, `address`, `contactname`, `contactno`, `relationship`, `created_at`, `registration_date`, `status`) VALUES
(43, '02000656506', 'Rogelio', 'Cyril Jane', NULL, 'B', '2025-04-07', 'rogelio.1234322nagastieduph', 'Female', '0951-103-3187', 'STEM', 'Grade 11', '', 'Minalabac Cam Sur', 'Jphnas', '0912-345-6695', 'Guardian', '2025-04-07 07:08:47', '2025-04-07 15:08:47', 'done'),
(44, '02000434686', 'Villamer', 'Jhona Mae', NULL, '', '2025-04-07', 'villamer123456@naga.stieduph', 'Female', '0951-103-3187', 'ABM', 'Grade 11', 'A', 'Bula Cam Sur', 'Asd', '0985-413-2410', 'Parent', '2025-04-07 11:08:45', '2025-04-07 19:08:45', 'done'),
(55, '02000424287', 'Nuestro', 'Justin Kyle', NULL, 'B', '2025-04-07', 'nuestro123445@naga.stieduph', 'Male', '0946-872-7196', 'BS Hospitality Management', '1st Year', '', 'Villa Corazon Q.C', 'Elaine Grace Nuestro', '0946-872-7196', 'Guardian', '2025-04-08 08:07:17', '2025-04-08 16:07:17', 'done'),
(56, '02000431490', 'Berce', 'Russel Ike', NULL, 'A', '2025-04-07', 'berce431490@naga.stieduph', 'Male', '0912-257-5787', 'BS Hospitality Management', '1st Year', 'A', 'Nabua Cam Sur', 'Rose Berce', '0912-255-7578', 'Parent', '2025-04-08 11:26:10', '2025-04-08 19:26:10', 'pending'),
(57, '02000425955', 'Pinon', 'Marc C', NULL, 'A', '2025-04-08', 'pinon425955@naga.stieduph', 'Male', '0956-860-3960', 'BS Hospitality Management', '1st Year', '', 'Bongoran Oas Albay', 'Preciosa Pinon', '0956-860-3960', 'Parent', '2025-04-08 11:29:21', '2025-04-08 19:29:21', 'done'),
(58, '02000429825', 'Dona', 'Kianjohn', NULL, 'S', '2025-04-08', 'dona429825@naga.stieduph', 'Male', '0956-438-1524', 'ABM', 'Grade 11', 'A', 'Oas Albay', 'Ronaliza Sano', '0956-860-3960', 'Parent', '2025-04-08 11:33:16', '2025-04-08 19:33:16', 'done'),
(59, '02000424731', 'Gavino', 'Aira Marie fs', NULL, 'M', '2025-04-08', 'gavino424731@naga.stieduph', 'Female', '0900-042-4731', 'BS Hospitality Management', '1st Year', 'A', 'Ratay Calabanga', 'Seth Gavino', '0930-054-5774', 'Guardian', '2025-04-08 11:35:35', '2025-04-08 19:35:35', 'done'),
(60, '02000421030', 'Imperial', 'Jessel', NULL, 'C', '2025-04-08', 'imperial421030@naga.stieduph', 'Male', '0992-037-5654', 'BS Information Technology', '1st Year', 'A', ' Pequena, Naga City', 'Irene Dela Rama', '0919-723-5114', 'Relative', '2025-04-08 11:39:23', '2025-04-08 19:39:23', 'pending'),
(61, '02000351756', 'Musne', 'Mike Lorence', NULL, 'L', '2006-12-18', 'musne.351756@nagastieduph', 'Male', '0991-371-8377', 'HUMSS', 'Grade 12', 'A', 'Magarao Camarines Sur', 'Gemma Musne', '0948-773-5606', 'Parent', '2025-04-11 04:59:52', '2025-04-11 12:59:52', 'pending'),
(62, '00200086653', 'Sdfsd', 'Sdfs', NULL, 'd', '2025-04-10', 'naga1233@gmail.com', 'Male', '0991-371-8377', 'ABM', 'Grade 11', 'A', 'sdfsdf', 'Sdfs', '0948-773-5606', 'Guardian', '2025-04-11 06:02:32', '2025-04-11 14:02:32', 'pending'),
(63, '00200088324', 'Sda', 'Asd', NULL, 'd', '2025-04-17', 'naga1233@gmail.com', 'Female', '0991-371-8377', 'ABM', 'Grade 11', 'A', 'sdfdsf', 'Gemma Musne', '0911-313-2321', 'Relative', '2025-04-12 02:46:29', '2025-04-12 10:46:29', 'pending'),
(64, '02000406520', 'Padua', 'Trexie', NULL, 'V', '2025-04-09', 'naga1233@gmail.com', 'Female', '0991-371-8377', 'BS Hospitality Management', '1st Year', 'A', 'Tinambac Camarines Sur', 'Marian Padua', '0945-747-4863', 'Parent', '2025-04-12 07:31:25', '2025-04-12 15:31:25', 'pending'),
(65, '02000235445', 'DEFSDF', 'DSF', NULL, 'S', '2025-04-17', 'naga1233@gmail.com', 'Male', '0991-371-8377', 'STEM', 'Grade 11', 'A', 'HFDH', 'GFGH', '0945-747-4863', 'Parent', '2025-04-12 08:52:24', '2025-04-12 16:52:24', 'done');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_registration`
--
ALTER TABLE `student_registration`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `studentno` (`studentno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student_registration`
--
ALTER TABLE `student_registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
